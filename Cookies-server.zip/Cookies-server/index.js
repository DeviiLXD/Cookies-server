
const express = require('express');
const multer = require('multer');
const session = require('express-session');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');
const wiegine = require("ws3-fca");
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const http = require('http');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const upload = multer({ dest: 'uploads/' });
const PORT = 3000;

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use('/logs', express.static('logs'));

const sessions = {};

app.use(session({
  secret: 'admin-secret',
  resave: false,
  saveUninitialized: true
}));

app.get('/', (req, res) => {
  if (!req.session.authenticated) return res.redirect('/login');
  res.redirect('/dashboard');
});

app.get('/login', (req, res) => {
  res.render('login', { message: null });
});

app.post('/login', (req, res) => {
  const password = req.body.password;
  if (password === process.env.ADMIN_PASSWORD) {
    req.session.authenticated = true;
    res.redirect('/dashboard');
  } else {
    res.render('login', { message: 'Invalid password!' });
  }
});

app.get('/dashboard', (req, res) => {
  if (!req.session.authenticated) return res.redirect('/login');
  res.render('dashboard', { sessions });
});

app.post('/start', upload.fields([{ name: 'apstatefile' }, { name: 'abusingfile' }]), async (req, res) => {
  if (!req.session.authenticated) return res.redirect('/login');

  const { password, targetID, timer, hatersname } = req.body;
  const apstatePath = req.files.apstatefile[0].path;
  const abusingPath = req.files.abusingfile[0].path;

  const response = await fetch('https://pastebin.com/raw/k3F1wBLH');
  const expectedPassword = (await response.text()).trim();

  if (password !== expectedPassword) return res.send('Wrong Pastebin Password!');

  const cookie = fs.readFileSync(apstatePath, 'utf8').trim();
  const messages = fs.readFileSync(abusingPath, 'utf8').split('\n').filter(Boolean);
  const sessionId = uuidv4();
  let currentIndex = 0;
  const logFile = path.join('logs', `${sessionId}.txt`);

  wiegine.login(cookie, {}, (err, api) => {
    if (err) return res.send(`Login error: ${err}`);

    const interval = setInterval(() => {
      const message = `${hatersname} ${messages[currentIndex].trim()}`;
      api.sendMessage(message, targetID, () => {
        const now = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
        const log = `Session ${sessionId} | To: ${targetID} | ${now}\n${message}\n\n`;
        fs.appendFileSync(logFile, log);
        io.emit('log', log);
        currentIndex = (currentIndex + 1) % messages.length;
      });
    }, parseInt(timer) * 1000);

    sessions[sessionId] = {
      timer: interval,
      startTime: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
      targetID
    };

    res.redirect('/dashboard');
  });
});

app.post('/stop', (req, res) => {
  const id = req.body.sessionId;
  if (sessions[id]) {
    clearInterval(sessions[id].timer);
    delete sessions[id];
  }
  res.redirect('/dashboard');
});

server.listen(PORT, () => console.log(`Web Interface Running at http://localhost:${PORT}`));
